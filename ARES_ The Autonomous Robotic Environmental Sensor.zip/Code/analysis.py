import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
from datetime import datetime
from datetime import timedelta
import matplotlib.ticker as ticker
import itertools
from numpy.lib import scimath as SM

'''Create empty Dataframe'''
my_index = pd.MultiIndex(levels=[[],[],[]],
                         codes=[[],[],[]],
                             names=[u'STime', u'Point', u'Index'])
my_columns = [u'Year', u'Month',u'Day',u'Hour',u'Minute',u'Second',u'x',u'y',u'theta',u'Record',u'U (m s^-1)',u'V (m s^-1)',u'W (m s^-1)',u'TSonic (K)',u'RH (%)',u'T_HMP60 (C)']
data = pd.DataFrame(index=my_index, columns=my_columns)

'''IMPORT DATA'''
files = ['08-00','08-30','09-00','09-30','10-00','10-30','11-00','11-30',
        '12-00','12-30','13-00','13-30','14-00','14-30','15-00','15-30',
        '16-00','16-30','17-00','17-30','18-00','18-30','19-00','19-30',
        '20-00','20-30','21-00','21-30','22-00','22-30','23-00','23-30',
        '00-00','00-30','01-00','01-30','02-00','02-30','03-00','03-30',
        '04-00','04-30','05-00','05-30','06-00','06-30','07-00','07-30']

for i in tqdm(files):
    temppd = pd.read_csv('./Data/Binned Data/'+i+'.csv',index_col=[0,1])
    
    #append dataframe into multiframe
    data = data.append(temppd.assign(k=i).set_index('k',append=True).swaplevel(0,2).swaplevel(1,2))
    
def crosscorr(x,y,lag):
    
    xmean = np.mean(x)
    ymean = np.mean(y)
    N = len(x)
    cross = np.zeros((N,1))
    tot = 0
    
    for j in range(lag):
        temp1=0
        temp2=0
        temp3=0
        xk=0
        yk=0
        xkj=0
        ykj=0
        for k in range(N-j-1):
            xk+=1/(N-j)*x[k]
            yk+=1/(N-j)*y[k]
            xkj+=1/(N-j)*x[k+j]
            ykj+=1/(N-j)*y[k+j]
        for k in range(N-j-1):
            temp1 += (x[k]-xk)*(y[k+j]-ykj)
            temp2 += (x[k]-xk)*(y[k]-yk)
            temp3 += (x[k+j]-xkj)*(y[k+j]-ykj)
            
        cross[j]=temp1/(SM.sqrt(temp2)*SM.sqrt(temp3))
        
        if np.sign(cross[0])!=np.sign(cross[j]):
            return sum(cross)
           
    return lag

def psum(x,sign):
    sum = 0
    sign = np.sign(x[0])
    if sign==-1:
        x = [ -i for i in x ]
    for i in range(len(x)):
        if x[i]<0:
            return sum*sign
        else:
            sum+=x[i]
    
    return sum*sign


points=['p1','p2','p3','p4','p5','p6','p7','p8']

my_index = pd.MultiIndex(levels=[[],[]],
                         codes=[[],[]],
                             names=[u'STime', u'Point'])
my_columns = [u'Uavg',u'Vavg',u'Wavg','Savg',u'TSonicavg',u'RHavg',u'T_HMP60avg',u'Uvar',u'Uvar_rerr',u'Vvar',u'Vvar_rerr',u'Wvar',u'Wvar_rerr',u'TSonicvar',u'TSonicvar_rerr',
              u'k',u'UVvar',u'UVvar_rerr',u'UWvar',u'UWvar_rerr',u'VWvar',u'VWvar_rerr',
              u'UTvar',u'UTvar_rerr',u'VTvar',u'VTvar_rerr',u'WTvar',u'WTvar_rerr',
             u'PMV1',u'PPD1',u'PMV2',u'PPD2',u'PMV3',u'PPD3',u'PMV4',u'PPD4',u'PMV5',u'PPD5',u'PMV6',u'PPD6',]

p_data = pd.DataFrame(index=my_index, columns=my_columns)

NIntegral = 600
AverageSample = len(data.loc[('08-00','p1'),'U (m s^-1)'])
WindowLength=int(AverageSample/2)
dt=0.1
SampleTime=AverageSample/10.

RUU=np.zeros((NIntegral,1))
RVV=np.zeros((NIntegral,1))
RWW=np.zeros((NIntegral,1))
RTT=np.zeros((NIntegral,1))
RUV=np.zeros((NIntegral,1))
RVW=np.zeros((NIntegral,1))
RUW=np.zeros((NIntegral,1))
RUT=np.zeros((NIntegral,1))
RVT=np.zeros((NIntegral,1))
RWT=np.zeros((NIntegral,1))

RUUALL=np.zeros((WindowLength,1))
RVVALL=np.zeros((WindowLength,1))
RWWALL=np.zeros((WindowLength,1))
RTTALL=np.zeros((WindowLength,1))
RUVALL=np.zeros((WindowLength,1))
RVWALL=np.zeros((WindowLength,1))
RUWALL=np.zeros((WindowLength,1))
RUTALL=np.zeros((WindowLength,1))
RVTALL=np.zeros((WindowLength,1))
RWTALL=np.zeros((WindowLength,1))


for dtime in tqdm(files):
    for point in points:
        p_data.loc[(dtime,point),'Uavg'] = np.mean(data.loc[(dtime,point),'U (m s^-1)'])
        p_data.loc[(dtime,point),'Vavg'] = np.mean(data.loc[(dtime,point),'V (m s^-1)'])
        p_data.loc[(dtime,point),'Wavg'] = np.mean(data.loc[(dtime,point),'W (m s^-1)'])
        p_data.loc[(dtime,point),'TSonicavg'] = np.mean(data.loc[(dtime,point),'TSonic (K)'])
        p_data.loc[(dtime,point),'RHavg'] = np.mean(data.loc[(dtime,point),'RH (%)'])
        p_data.loc[(dtime,point),'T_HMP60avg'] = np.mean(data.loc[(dtime,point),'T_HMP60 (C)'])+273.15 #shift to Kelvin
        p_data.loc[(dtime,point),'Savg'] = np.mean(np.sqrt(data.loc[(dtime,point),'U (m s^-1)']**2+
                                                           data.loc[(dtime,point),'V (m s^-1)']**2+
                                                           data.loc[(dtime,point),'W (m s^-1)']**2))
        
        
        x = [j for j in range(0, len(data.loc[(dtime,point),'U (m s^-1)']))]
        U = data.loc[(dtime,point),'U (m s^-1)']
        Umodel = np.polyfit(x,U,1)
        Utrend = np.polyval(Umodel,x)
        Udetrended = U - Utrend
        V = data.loc[(dtime,point),'V (m s^-1)']
        Vmodel = np.polyfit(x,V,1)
        Vtrend = np.polyval(Vmodel,x)
        Vdetrended = V - Vtrend
        W = data.loc[(dtime,point),'W (m s^-1)']
        Wmodel = np.polyfit(x,W,1)
        Wtrend = np.polyval(Wmodel,x)
        Wdetrended = W - Wtrend
        TSonic =  data.loc[(dtime,point),'TSonic (K)']
        TSonicmodel = np.polyfit(x, TSonic,1)
        TSonictrend = np.polyval( TSonicmodel,x)
        TSonicdetrended =  TSonic -  TSonictrend
        
        UVCovMatrix = np.cov(Udetrended, Vdetrended)
        UWCovMatrix = np.cov(Udetrended, Wdetrended)
        VWCovMatrix = np.cov(Vdetrended, Wdetrended)
        UTSonicCovMatrix = np.cov(Udetrended, TSonicdetrended)
        VTSonicCovMatrix = np.cov(Vdetrended, TSonicdetrended)
        WTSonicCovMatrix = np.cov(Wdetrended, TSonicdetrended)

        p_data.loc[(dtime,point),'Uvar'] = UVCovMatrix[0,0]
        p_data.loc[(dtime,point),'Vvar'] = UVCovMatrix[1,1]
        p_data.loc[(dtime,point),'Wvar'] = UWCovMatrix[1,1]
        p_data.loc[(dtime,point),'TSonicvar'] = UTSonicCovMatrix[1,1]
        p_data.loc[(dtime,point),'k'] = 1/2*(p_data.loc[(dtime,point),'Uvar']+p_data.loc[(dtime,point),'Vvar']+p_data.loc[(dtime,point),'Wvar'])

        p_data.loc[(dtime,point),'UVvar'] = UVCovMatrix[0,1]
        p_data.loc[(dtime,point),'UWvar'] = UWCovMatrix[0,1]
        p_data.loc[(dtime,point),'VWvar'] = VWCovMatrix[0,1]
        p_data.loc[(dtime,point),'UTvar'] = UTSonicCovMatrix[0,1]
        p_data.loc[(dtime,point),'VTvar'] = VTSonicCovMatrix[0,1]
        p_data.loc[(dtime,point),'WTvar'] = WTSonicCovMatrix[0,1]
        
        Udetrended = Udetrended.to_numpy()
        Vdetrended = Vdetrended.to_numpy()
        Wdetrended = Wdetrended.to_numpy()
        TSonicdetrended = TSonicdetrended.to_numpy()
        
    
        #Calculate integral scales (these are typically on the scale of 1-5 seconds)  
        TauUU = crosscorr(Udetrended,Udetrended, NIntegral)*dt
        TauVV = crosscorr(Vdetrended,Vdetrended, NIntegral)*dt
        TauWW = crosscorr(Wdetrended,Wdetrended, NIntegral)*dt
        TauTT = crosscorr(TSonicdetrended,TSonicdetrended, NIntegral)*dt
        TauUV = crosscorr(Udetrended,Vdetrended, NIntegral)*dt
        TauUW = crosscorr(Udetrended,Wdetrended, NIntegral)*dt
        TauVW = crosscorr(Vdetrended,Wdetrended, NIntegral)*dt
        TauUT = crosscorr(Udetrended,TSonicdetrended, NIntegral)*dt
        TauVT = crosscorr(Vdetrended,TSonicdetrended, NIntegral)*dt
        TauWT = crosscorr(Wdetrended,TSonicdetrended, NIntegral)*dt
        
        #Adjust for Systematic Error
        p_data.loc[(dtime,point),'Uvar'] *=2*TauUU/SampleTime+1
        p_data.loc[(dtime,point),'Vvar'] *=2*TauVV/SampleTime+1
        p_data.loc[(dtime,point),'Wvar'] *=2*TauWW/SampleTime+1
        p_data.loc[(dtime,point),'TSonicvar'] *=2*TauTT/SampleTime+1
        p_data.loc[(dtime,point),'UVvar'] *=2*TauUV/SampleTime+1
        p_data.loc[(dtime,point),'UWvar'] *=2*TauUW/SampleTime+1
        p_data.loc[(dtime,point),'VWvar'] *=2*TauVW/SampleTime+1
        p_data.loc[(dtime,point),'UTvar'] *=2*TauUT/SampleTime+1
        p_data.loc[(dtime,point),'VTvar'] *=2*TauVT/SampleTime+1
        p_data.loc[(dtime,point),'WTvar'] *=2*TauWT/SampleTime+1
        
	#Save the Random Error (In case you want to check it)
        p_data.loc[(dtime,point),'Uvar_rerr'] =np.sqrt(2*TauUU/SampleTime)
        p_data.loc[(dtime,point),'Vvar_rerr'] =np.sqrt(2*TauVV/SampleTime)
        p_data.loc[(dtime,point),'Wvar_rerr'] =np.sqrt(2*TauWW/SampleTime)
        p_data.loc[(dtime,point),'TSonicvar_rerr'] =np.sqrt(2*TauTT/SampleTime)
        p_data.loc[(dtime,point),'UVvar_rerr'] =np.sqrt(2*TauUV/SampleTime)
        p_data.loc[(dtime,point),'UWvar_rerr'] =np.sqrt(2*TauUW/SampleTime)
        p_data.loc[(dtime,point),'VWvar_rerr'] =np.sqrt(2*TauVW/SampleTime)
        p_data.loc[(dtime,point),'UTvar_rerr'] =np.sqrt(2*TauUT/SampleTime)
        p_data.loc[(dtime,point),'VTvar_rerr'] =np.sqrt(2*TauVT/SampleTime)
        p_data.loc[(dtime,point),'WTvar_rerr'] =np.sqrt(2*TauWT/SampleTime)


'''Calibrate the USonic temperatures'''

#plt.scatter(p_data['TSonicavg'],p_data['T_HMP60avg']) #check pre-calibration if desired
#plt.show()

#print(p_data['TSonicavg'].tolist())
results = {}
x=p_data['TSonicavg'].tolist()
y=p_data['T_HMP60avg'].tolist()

coeffs = np.polyfit(x,y, 1)

results['polynomial'] = coeffs.tolist()
# r-squared
p = np.poly1d(coeffs)
# fit values, and mean
yhat = p(x)                         # or [p(z) for z in x]
ybar = np.sum(y)/len(y)          # or sum(y)/len(y)
ssreg = np.sum((yhat-ybar)**2)   # or sum([ (yihat - ybar)**2 for yihat in yhat])
sstot = np.sum((y - ybar)**2)    # or sum([ (yi - ybar)**2 for yi in y])
results['determination'] = ssreg / sstot

print(results)

p_data['TSonicavg']=p_data['TSonicavg']*results['polynomial'][0]+results['polynomial'][1]


def calculatePmv(ta, tr, vel, rh, met, clo, wme): #THIS CALCULATES PMV AND PPD (SUPER USEFUL!)
      #returns [pmv, ppd]
      #ta, air temperature (C)
      #tr, mean radiant temperature (C)
      #vel, relative air speed (m/s)
      #rh, relative humidity (%) Used only this way to input humidity level
      #met, metabolic rate (met)
      #clo, clothing (clo)
      #wme, external work, normally around 0 (met)

    pa = rh * 10 * np.exp(16.6536 - 4030.183 / (ta + 235))
    
    icl = 0.155 * clo #thermal insulation of the clothing in [m^2 K W^-1]
    m = met * 58.15 #metabolic rate in [W m^-2]
    w = wme * 58.15 #external work in [W m^-2]
    mw = m - w #internal heat production in the human body
    
    fcl = 1 + 1.29 * icl if icl <= 0.078 else 1.05 + 0.645 * icl

    #heat transf. coeff. by forced convection
    hcf = 12.1 * np.sqrt(vel)
    taa = ta + 273
    tra = tr + 273
    #we have verified that using the equation below or this tcla = taa + (35.5 - ta) / (3.5 * (6.45 * icl + .1)) does not affect the PMV value
    tcla = taa + (35.5 - ta) / (3.5 * icl + 0.1)

    p1 = icl * fcl
    p2 = p1 * 3.96
    p3 = p1 * 100
    p4 = p1 * taa
    p5 = 308.7 - 0.028 * mw + p2 * (tra / 100) ** 4

    xn = tcla / 100
    xf = tcla / 50
    eps = 0.00015

    n = 0
    hc = 0
    while (np.abs(xn - xf) > eps):
        xf = (xf + xn) / 2
        hcn = 2.38 * np.abs(100.0 * xf - taa) ** 0.25
        hc = hcf if hcf > hcn else hcn

        xn = (p5 + p4 * hc - p2 * xf ** 4) / (100 + p3 * hc)
        n+=1
        if (n > 150):
            print("Max iterations exceeded")
            return 1
        
    

    tcl = 100 * xn - 273;

    #heat loss diff. through skin
    hl1 = 3.05 * 0.001 * (5733 - 6.99 * mw - pa)
    #heat loss by sweating
    hl2 = 0.42 * (mw - 58.15) if (mw > 58.15) else 0
    #latent respiration heat loss
    hl3 = 1.7 * 0.00001 * m * (5867 - pa)
    #dry respiration heat loss
    hl4 = 0.0014 * m * (34 - ta)
    #heat loss by radiation
    hl5 = 3.96 * fcl * (xn ** 4 - (tra / 100) ** 4)
    #heat loss by convection
    hl6 = fcl * hc * (tcl - ta)

    ts = 0.303 * np.exp(-0.036 * m) + 0.028
    pmv = ts * (mw - hl1 - hl2 - hl3 - hl4 - hl5 - hl6)
    ppd = 100.0 - 95.0 * np.exp(-0.03353 * pmv ** 4.0 - 0.2179 * pmv ** 2.0)

    return [pmv,ppd]






for dtime in tqdm(files):
    for point in points:
        PMV= calculatePmv(p_data.loc[(dtime,point),'TSonicavg']-273, p_data.loc[(dtime,point),'TSonicavg']-273+0.3, p_data.loc[(dtime,point),'Savg'], p_data.loc[(dtime,point),'RHavg'], 1.1, 0.57, 0)
        p_data.loc[(dtime,point),'PMV1'] = PMV[0]
        p_data.loc[(dtime,point),'PPD1'] = PMV[1]
        
        PMV= calculatePmv(p_data.loc[(dtime,point),'TSonicavg']-273, p_data.loc[(dtime,point),'TSonicavg']-273+0.3, p_data.loc[(dtime,point),'Savg'], p_data.loc[(dtime,point),'RHavg'], 1.1, 0.74, 0)
        p_data.loc[(dtime,point),'PMV2'] = PMV[0]
        p_data.loc[(dtime,point),'PPD2'] = PMV[1]
        
        PMV= calculatePmv(p_data.loc[(dtime,point),'TSonicavg']-273, p_data.loc[(dtime,point),'TSonicavg']-273+0.3, p_data.loc[(dtime,point),'Savg'], p_data.loc[(dtime,point),'RHavg'], 1.1, 0.96, 0)
        p_data.loc[(dtime,point),'PMV3'] = PMV[0]
        p_data.loc[(dtime,point),'PPD3'] = PMV[1]
        
        PMV= calculatePmv(p_data.loc[(dtime,point),'TSonicavg']-273, p_data.loc[(dtime,point),'TSonicavg']-273+0.3, p_data.loc[(dtime,point),'Savg'], p_data.loc[(dtime,point),'RHavg'], 1.7, 0.57, 0)
        p_data.loc[(dtime,point),'PMV4'] = PMV[0]
        p_data.loc[(dtime,point),'PPD4'] = PMV[1]
        
        PMV= calculatePmv(p_data.loc[(dtime,point),'TSonicavg']-273, p_data.loc[(dtime,point),'TSonicavg']-273+0.3, p_data.loc[(dtime,point),'Savg'], p_data.loc[(dtime,point),'RHavg'], 1.7, 0.74, 0)
        p_data.loc[(dtime,point),'PMV5'] = PMV[0]
        p_data.loc[(dtime,point),'PPD5'] = PMV[1]
        
        PMV= calculatePmv(p_data.loc[(dtime,point),'TSonicavg']-273, p_data.loc[(dtime,point),'TSonicavg']-273+0.3, p_data.loc[(dtime,point),'Savg'], p_data.loc[(dtime,point),'RHavg'], 1.7, 0.96, 0)
        p_data.loc[(dtime,point),'PMV6'] = PMV[0]
        p_data.loc[(dtime,point),'PPD6'] = PMV[1]

'''Below is for saving figures'''
figsavepath = './Analysis/Figures/24Hr_'


x_axis_labels = ['16-00','17-00','18-00','19-00',
            '20-00','21-00','22-00','23-00',
            '00-00','01-00','02-00','03-00',
            '04-00','05-00','06-00','07-00',
            '08-00','09-00','10-00','11-00',
            '12-00','13-00','14-00','15-00']

marker = itertools.cycle(('.'))
colors = {'p1':'b'}



fig = plt.figure(figsize=(7,3),dpi=600)
ax=plt.subplot(111)
for i in points:
    ax.plot(files,p_data.loc[pd.IndexSlice[:, i], 'T_HMP60avg'],marker = next(marker),linewidth=1,label=i)
plt.ylabel(r'$\overline{T}_{HMP60}$ [K]')
xlabel = plt.xlabel('Time [EDT]')
plt.xticks(rotation=40,ha="right")
lgd = ax.legend(bbox_to_anchor=(1.01, 1), loc='upper left')
plt.xticks(x_axis_labels)
plt.savefig(figsavepath+'HMP60_T_avg.pdf', format='pdf',bbox_extra_artists=(lgd,xlabel), bbox_inches='tight')
plt.show()


fig = plt.figure(figsize=(7,3),dpi=300)
ax=plt.subplot(111)
for i in points:
    ax.plot(files,p_data.loc[pd.IndexSlice[:, i], 'TSonicavg'],marker = next(marker),linewidth=1,label=i)
plt.ylabel(r'$\overline{T}_{US}$ [K]')
xlabel = plt.xlabel('Time [EDT]')
plt.xticks(rotation=50,ha="right")
lgd = ax.legend(bbox_to_anchor=(1.01, 1), loc='upper left')
plt.xticks(x_axis_labels)
plt.savefig(figsavepath+'SonicT_avg.pdf', format='pdf',bbox_extra_artists=(lgd,xlabel), bbox_inches='tight')
plt.show()


fig = plt.figure(figsize=(7,3),dpi=300)
ax=plt.subplot(111)
for i in points:
    ax.plot(files,p_data.loc[pd.IndexSlice[:, i], 'RHavg'],marker = next(marker),linewidth=1,label=i)
plt.ylabel(r'$\overline{RH}$ [%]')
xlabel = plt.xlabel('Time [EDT]')
plt.xticks(rotation=60,ha="right")
lgd = ax.legend(bbox_to_anchor=(1.01, 1), loc='upper left')
plt.xticks(x_axis_labels)
plt.savefig(figsavepath+'RH_avg.pdf', format='pdf',bbox_extra_artists=(lgd,xlabel), bbox_inches='tight')
plt.show()