import numpy as np
import pandas as pd

filename = "output.txt"

df = pd.read_csv(filename,
                delimiter = '\t',
                names = ['x','y','theta'])

newframe = pd.DataFrame(columns = ['x','y','theta'])

measurement_time=160*50 #time to sample multiplied by controller frequency

dict={}
for pathnum in range(1,9):
    print(pathnum)
    filename = "path"+str(pathnum)+".txt"
    df = pd.read_csv(filename,
                delimiter = '\t',
                names = ['x','y','theta'])
    
    for i in range(len(df)-1): #split into smaller steps using lin spaces
        dictlen=len(dict)
        if (df['x'][i]!=df['x'][i+1] and df['y'][i]!=df['y'][i+1]):
            x=np.linspace(df['x'][i],df['x'][i+1],num=4)
            y=np.linspace(df['y'][i],df['y'][i+1],num=4)
            t=np.linspace(df['theta'][i],df['theta'][i+1],num=4)
            for j in range(3):
                dict[dictlen+j] = {'x':x[j],'y':y[j],'theta':t[j]}
        else:
            x=np.linspace(df['x'][i],df['x'][i+1],num=4)
            y=np.linspace(df['y'][i],df['y'][i+1],num=4)
            t=np.linspace(df['theta'][i],df['theta'][i+1],num=4)
            for j in range(3):
                dict[dictlen+j] = {'x':x[j],'y':y[j],'theta':t[j]}
    
    dictlen=len(dict)
    for i in range(measurement_time): #fill in time at point
        dict[dictlen+i] = {'x':df['x'].iloc[-1],'y':df['y'].iloc[-1],'theta':df['theta'].iloc[-1]}
        
newframe = pd.DataFrame.from_dict(dict, "index")

newframe.to_csv('finalpath_slow.csv',index=False)