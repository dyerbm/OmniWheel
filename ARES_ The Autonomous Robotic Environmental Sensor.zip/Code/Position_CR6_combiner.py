import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
from datetime import datetime
from datetime import timedelta

position_path = "./Data/"
data_path = "./Data/RealRun/"
output_path ="./"



'''Create single CR6 dataframe with datetime for comparisons'''
dict={}
for i in tqdm(range(5462,13774)): #create dataframe of all CR6 data
    try:
        outputsize = len(dict)

        df_CR6 = pd.read_table(data_path+"Younng10Hz"+str(i)+".dat",
                           sep=",",
                          skiprows=[0,2,3])

        for j in range(len(df_CR6)):
            if "." in df_CR6['TIMESTAMP'][j]:
                date = datetime.strptime(df_CR6['TIMESTAMP'][j], '%Y-%m-%d %H:%M:%S.%f')
            else:
                date = datetime.strptime(df_CR6['TIMESTAMP'][j], '%Y-%m-%d %H:%M:%S')

            dict[outputsize+j]={"TIMESTAMP":date,"Record":df_CR6['RECORD'][j],"U (m s^-1)":df_CR6['U'][j],"V (m s^-1)":df_CR6['V'][j],"W (m s^-1)":df_CR6['W'][j],"TSonic (K)":df_CR6['TSonic'][j],"RH (%)":df_CR6['RH'][j],"T_HMP60 (C)":df_CR6['T_HMP60'][j]}    

    
    except: #if the file is missing just skip it (this happens twice, nothing needed luckily)
        pass
        
df_CR6 = pd.DataFrame.from_dict(dict, "index") #convert dict to dataframe (this is faster)

'''START LOOP HERE!!!'''
inputFiles = ['2020-10-02 16-00.xlsx','2020-10-02 16-30.xlsx','2020-10-02 17-00.xlsx','2020-10-02 17-31.xlsx','2020-10-02 18-00.xlsx','2020-10-02 18-30.xlsx','2020-10-02 19-00.xlsx','2020-10-02 19-30.xlsx','2020-10-02 20-00.xlsx','2020-10-02 20-30.xlsx','2020-10-02 21-00.xlsx','2020-10-02 21-30.xlsx','2020-10-02 22-00.xlsx','2020-10-02 22-30.xlsx','2020-10-02 23-00.xlsx','2020-10-02 23-30.xlsx','2020-10-03 00-00.xlsx','2020-10-03 00-30.xlsx','2020-10-03 01-00.xlsx','2020-10-03 01-30.xlsx','2020-10-03 02-00.xlsx','2020-10-03 02-30.xlsx','2020-10-03 03-00.xlsx','2020-10-03 03-30.xlsx','2020-10-03 04-00.xlsx','2020-10-03 04-30.xlsx','2020-10-03 05-00.xlsx','2020-10-03 05-30.xlsx','2020-10-03 06-00.xlsx','2020-10-03 06-30.xlsx', '2020-10-03 07-00.xlsx','2020-10-03 07-30.xlsx','2020-10-08 08-00.xlsx','2020-10-08 08-30.xlsx','2020-10-08 09-00.xlsx','2020-10-08 09-30.xlsx','2020-10-08 10-00.xlsx','2020-10-08 10-30.xlsx','2020-10-08 11-00.xlsx','2020-10-08 11-30.xlsx','2020-10-08 12-00.xlsx','2020-10-08 12-30.xlsx','2020-10-08 13-00.xlsx','2020-10-08 13-30.xlsx','2020-10-08 14-00.xlsx','2020-10-08 14-30.xlsx','2020-10-08 15-00.xlsx','2020-10-02 15-30.xlsx']


outputFiles = ['16-00','16-30','17-00','17-30','18-00','18-30','19-00','19-30','20-00','20-30','21-00','21-30','22-00','22-30','23-00','23-30','00-00','00-30','01-00','01-30','02-00','02-30','03-00','03-30','04-00','04-30','05-00','05-30','06-00','06-30','07-00','07-30','08-00','08-30','09-00','09-30','10-00','10-30','11-00','11-30','12-00','12-30','13-00','13-30','14-00','14-30','15-00','15-30']


for j in tqdm(range(len(inputFiles))):
    df_pos = pd.read_excel(position_path+inputFiles[j], header=None)
    df_pos.columns = ['TIMESTAMP', 'X', 'Y', 'THETA']

    '''Create proper timestamps for position'''
    dict ={}
    for i in tqdm(range(len(df_pos))):
        dict[i]={'TIMESTAMP': datetime.fromordinal(int(df_pos['TIMESTAMP'][i])) + timedelta(days=df_pos['TIMESTAMP'][i]%1) - timedelta(days = 366),'X':df_pos['X'][i],'Y':df_pos['Y'][i],'THETA':df_pos['THETA'][i]}
    df_pos = pd.DataFrame.from_dict(dict, "index")



    '''Trim CR6 data based on timestamps from position data. Use new dataframe.'''
    
    df_CR6_trim= df_CR6.iloc[df_CR6.index[(df_CR6['TIMESTAMP'] == df_pos['TIMESTAMP'].iloc[0].round('100ms'))].tolist()[0]:
                         df_CR6.index[(df_CR6['TIMESTAMP'] == df_pos['TIMESTAMP'].iloc[-1].round('100ms'))].tolist()[0]]

    df_CR6_trim.reset_index(inplace=True, drop=True)


    '''Create a combined database'''
    dict={}
    for i in tqdm(range(len(df_CR6_trim))):
        date = df_CR6_trim["TIMESTAMP"].iloc[i]
        index = (df_pos['TIMESTAMP']-date).abs().argsort()[:2].iloc[1]

        x = df_pos['X'].iloc[index]
        y = df_pos['Y'].iloc[index]
        theta = df_pos['THETA'].iloc[index]

        dict[i]= {"Year":date.year,"Month":date.month,"Day":date.day,"Hour":date.hour,
                  "Minute":date.minute,"Second":date.second+date.microsecond/1000000.,
                  "x":x,"y":y,"theta":theta,
                  "Record":df_CR6_trim['Record'][i],"U (m s^-1)":df_CR6_trim['U (m s^-1)'][i],"V (m s^-1)":df_CR6_trim['V (m s^-1)'][i],
                  "W (m s^-1)":df_CR6_trim['W (m s^-1)'][i],"TSonic (K)":df_CR6_trim['TSonic (K)'][i],"RH (%)":df_CR6_trim['RH (%)'][i],
                  "T_HMP60 (C)":df_CR6_trim['T_HMP60 (C)'][i]}


    df_comb = pd.DataFrame.from_dict(dict, "index")


    '''Create MultiIndex based on each point'''
    point_dict={'p1':[2.8,0.7,0], 'p2':[6.0,0.7,0], 'p3':[6.0,4.4,0], 'p4':[2.8,4.4,0],
               'p5':[6.0,7.9,0], 'p6':[2.8,7.9,0], 'p7':[6.0,10.6,0], 'p8':[4.9,11.8,0]}

    drop=50 #frequency*seconds to drop, make sure the robot is in the correct positon

    dict={'p1':{},'p2':{},'p3':{},'p4':{},'p5':{},'p6':{},'p7':{},'p8':{}}

    for i in tqdm(range(drop, len(df_comb)-drop)):
        if ([df_comb['x'].iloc[i-drop],df_comb['y'].iloc[i-drop],df_comb['theta'].iloc[i-drop]] in point_dict.values() and
           [df_comb['x'].iloc[i+drop],df_comb['y'].iloc[i+drop],df_comb['theta'].iloc[i+drop]] in point_dict.values() and 
           [df_comb['x'].iloc[i],df_comb['y'].iloc[i],df_comb['theta'].iloc[i]] in point_dict.values()): #Check that it has been there for a while

            point = list(point_dict.keys())[list(point_dict.values()).index([df_comb['x'].iloc[i],df_comb['y'].iloc[i],df_comb['theta'].iloc[i]])] #get the point

            dict[point][i]=df_comb.iloc[i].to_dict()


    dict_of_df = {k: pd.DataFrame(v) for k,v in dict.items()}
    output = pd.concat(dict_of_df, axis=1).transpose()
    output.to_csv('./Data/Binned Data/'+outputFiles[j]+'.csv',index=True) #save dat data